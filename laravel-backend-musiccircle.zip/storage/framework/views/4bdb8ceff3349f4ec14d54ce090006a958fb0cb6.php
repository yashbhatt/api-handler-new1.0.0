<?php
    echo 'fk this shit ';
?>
<?php /**PATH C:\project_analogue\api_handler(new)\resources\views/memez.blade.php ENDPATH**/ ?>