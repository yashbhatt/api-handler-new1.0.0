<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class drackController extends Controller
{
    // create drack
    public function create_drack () {

    }
    // add product to drack
    public function add_to_drack (product_id,) {

    }
    // del from rack
    // trasfer rack (use the products table for all of this.)
}
