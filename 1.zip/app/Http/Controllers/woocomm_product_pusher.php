<?php

namespace App\Http\Controllers\woocomm_part;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class woocomm_product_pusher extends Controller
{

}
