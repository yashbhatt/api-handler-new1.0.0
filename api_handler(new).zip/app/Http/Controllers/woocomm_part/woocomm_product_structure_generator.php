<?php

namespace App\Http\Controllers\woocomm_part;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class woocomm_product_structure_generator extends Controller
{
    // public $request;
    // public $returning_obj;

    // public function __construct($reqest)
    // {
    //     $this->request = $reqest;
    // }

    // public function make_woocommerce_structured_product () {
    //     return $this->sanitize_artist_title();
    // }



    // public function sanitize_tracklist() {
    //     // dd($this->request);
    // }

    // public function sanitize_artist_title () {
    //     return $this->reqest->artist_title;
    // }
}
