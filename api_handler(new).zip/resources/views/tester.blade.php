<?php
    echo "You have reached the testing page";
?>
